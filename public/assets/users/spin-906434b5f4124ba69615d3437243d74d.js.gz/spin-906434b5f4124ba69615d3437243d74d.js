(function() {
  $(document).ready(function() {
    return $('.spin').click(function() {
      return $(this).spin();
    });
  });

}).call(this);
